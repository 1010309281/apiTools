### 文档书写规范

> title名称

<view class="api-title">xxx</view>

> api描述

<view class="api-desc">xxx</view>

> Api接口地址

<view class="api-url">xxx</view>

> 返回格式

<view class="api-reponse-format">xxx</view>

> 请求方式

<view class="api-request-method">xxx</view>

> 请求示例

<view class="api-request-demo">

```json

```

</view>

> 请求参数说明

<view class="request-param">

字段名称 | 类型 | 必填 | 说明
--- | --- | --- | ---
xxx | xxx | xxx | xxx

</view>

> 返回示例

<view class="api-reponse-demo">

```json

```

</view>

> 返回参数说明

<view class="reponse-param">

字段名称 | 类型 | 说明
--- | --- | ---
xxx | xxx | xxx

</view>

> 错误码参照

<view class="error-param">

字段名称 | 类型 | 说明
--- | --- | ---
xxx | xxx | xxx

</view>


> 示例代码

<div class="code-demo">

```go

```

</div>