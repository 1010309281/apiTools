### 格式文档书写规范

```json5
{
   "whoisquery": {                 // api名称，要与配置的路由名称一致
    "docFile": "whois.json",    // docs数据存储文件
    "countKey": "whoisquery",    // redis统计请求次数key名
   }
}
```